#ifndef UTIL_H
#define UTIL_H

#include <vector>
#include <string>
#include <sstream>

using namespace std;

void split_string(const string& s, vector<string>& ret);


#endif // !UTIL_H
