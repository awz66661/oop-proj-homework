#ifndef GUARD_grade_h
#define GUARD_grade_h


//TODO
#include <iostream>
#include <string>
#include <iomanip>
#include <stdexcept>
#include <algorithm>
#include <list>
#include <vector>
#include "median.h"
#include "grade.h"
#include "Student_info.h"

using namespace std;

double grade(double midterm, double final, std::vector<double>& hw);

#endif
