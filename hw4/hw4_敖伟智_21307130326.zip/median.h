#ifndef GUARD_median_h
#define GUARD_median_h

//TODO
#include <vector>
double median(std::vector<double> vec);

#endif
